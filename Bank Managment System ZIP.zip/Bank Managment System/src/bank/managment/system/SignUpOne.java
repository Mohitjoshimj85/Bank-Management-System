package bank.managment.system;

import  javax.swing.*;
import java.awt.*;
import java.util.*;
import com.toedter.calendar.JDateChooser ;
import java.awt.event.*;

public class SignUpOne extends JFrame implements ActionListener{
    long random;
    JTextField nameField , fnameField , emailField, addressField, cityField ,stateField, pinField;
    JRadioButton male , female , married , unmarried;
    JDateChooser dobChooser;
    SignUpOne(){
        setLayout(null);
        
        random = Math.abs((new Random().nextLong() % 9000l) + 1000l);
        JLabel heading = new JLabel("APPICATION FORM : "+ random );
        heading.setFont(new Font("Osward" , Font.BOLD ,40));
        heading.setBounds(170, 30 , 500 , 40);
        add(heading);
        
        JLabel page1= new JLabel("Page 1 : Personal Details ");
        page1.setFont(new Font("Ralewey" , Font.BOLD , 25));
        page1.setBounds(280, 80, 400, 30);
        add(page1);
        
        JLabel name= new JLabel("Name : ");
        name.setFont(new Font("Raleway" , Font.BOLD , 25));
        name.setBounds(150, 140, 200, 30);
        add(name);
        
        nameField = new JTextField();
        nameField.setFont(new Font("Raleway" ,Font.BOLD , 20));
        nameField.setBounds(400, 140, 300, 30);
        add(nameField);
        
        JLabel fname= new JLabel("Father's Name : ");
        fname.setFont(new Font("Raleway" , Font.BOLD , 25));
        fname.setBounds(150, 190, 200, 30);
        add(fname);
        
        fnameField = new JTextField();
        fnameField.setFont(new Font("Raleway" ,Font.BOLD , 20));
        fnameField.setBounds(400, 190, 300, 30);
        add(fnameField);
        
        JLabel dob = new JLabel("Date of Birth : ");
        dob.setFont(new Font("Raleway" , Font.BOLD , 25));
        dob.setBounds(150, 230, 200, 30);
        add(dob);
        
        dobChooser = new JDateChooser();
        dobChooser.setBounds(400,230, 300, 30);
        add(dobChooser);
        
        JLabel gender= new JLabel("Gender : ");
        gender.setFont(new Font("Raleway" , Font.BOLD , 25));
        gender.setBounds(150, 280, 200, 30);
        add(gender);
        
        male= new JRadioButton("male");
        male.setBounds(400, 280, 100, 30);
        add(male);
        
        female = new JRadioButton("female");
        female.setBounds(600, 280, 100, 30);
        add(female);
        
        ButtonGroup genderGroup= new ButtonGroup();
        genderGroup.add(male);
        genderGroup.add(female);
        
        
        JLabel emial= new JLabel("Email Address : ");
        emial.setFont(new Font("Raleway" , Font.BOLD , 25));
        emial.setBounds(150, 330, 200, 30);
        add(emial);
        
        emailField = new JTextField();
        emailField.setFont(new Font("Raleway" ,Font.BOLD , 20));
        emailField.setBounds(400, 330, 300, 30);
        add(emailField);
        
        JLabel marital= new JLabel("Marital Status : ");
        marital.setFont(new Font("Raleway" , Font.BOLD , 25));
        marital.setBounds(150, 380, 200, 30);
        add(marital);
        
        married= new JRadioButton("Married");
        married.setBounds(400, 380, 100, 30);
        add(married);
        
        unmarried = new JRadioButton("UnMarried");
        unmarried.setBounds(600, 380, 100, 30);
        add(unmarried);
        
        ButtonGroup maritalGroup= new ButtonGroup();
        maritalGroup.add(married);
        maritalGroup.add(unmarried);
        
        JLabel address= new JLabel("Address : ");
        address.setFont(new Font("Raleway" , Font.BOLD , 25));
        address.setBounds(150, 430, 200, 30);
        add(address);
        
        addressField = new JTextField();
        addressField.setFont(new Font("Raleway" ,Font.BOLD , 20));
        addressField.setBounds(400, 430, 300, 30);
        add(addressField); 
        
        JLabel city= new JLabel("City : ");
        city.setFont(new Font("Raleway" , Font.BOLD , 25));
        city.setBounds(150, 480, 200, 30);
        add(city);
        
        cityField = new JTextField();
        cityField.setFont(new Font("Raleway" ,Font.BOLD , 20));
        cityField.setBounds(400, 480, 300, 30);
        add(cityField);
        
        JLabel state= new JLabel("State : ");
        state.setFont(new Font("Raleway" , Font.BOLD , 25));
        state.setBounds(150, 530, 200, 30);
        add(state);
        
        stateField = new JTextField();
        stateField.setFont(new Font("Raleway" ,Font.BOLD , 20));
        stateField.setBounds(400, 530, 300, 30);
        add(stateField);
        
        JLabel pin= new JLabel("Pin Code : ");
        pin.setFont(new Font("Raleway" , Font.BOLD , 25));
        pin.setBounds(150, 580, 200, 30);
        add(pin);
        
        pinField = new JTextField();
        pinField.setFont(new Font("Raleway" ,Font.BOLD , 20));
        pinField.setBounds(400, 580, 300, 30);
        add(pinField);
        
        JButton nextButton= new JButton();
        nextButton.setText("NEXT");
        nextButton.setFont(new Font("RaleWay", Font.BOLD ,25));
        nextButton.setBounds(600, 650, 110, 40);
        nextButton.addActionListener(this);
        add(nextButton);
        
        getContentPane().setBackground(Color.white);
        setSize(850 , 800 );
        setVisible(true);
        setLocation(350, 10);
        
    }
    
    public void actionPerformed(ActionEvent ac ){
        String formNo = ""+ random;
        String name = nameField.getText();
        String fname = fnameField.getText(); 
        String email = emailField.getText(); 
        String address = addressField.getText() ; 
        String city =  cityField.getText();
        String state = stateField.getText() ; 
        String pin = pinField.getText();
        
        String date = ((JTextField) dobChooser.getDateEditor().getUiComponent()  ).getText();
        String gender =  null;
        if(male.isSelected()){
            gender = "male";
        }else if( female.isSelected()){
            gender = "female";
        }
        
        String marital = null;
        if(married.isSelected()){
            marital = "married";
        }else if( unmarried.isSelected()){
            marital = "unmarried";
        }
        
        try {
            Conn c =  new Conn();
            System.out.println("INSERT  INTO signup VALUES ( '" + formNo + "' , '"+ name+ "' , '"+ fname+ "' , '"+ date+ "' , '"+ gender+ "' , '"+ email+ "' , '"+ marital + "' , '"+ address + "' , '"+  city + "' , '"+  state + "' , '"+  pin+ "' ); ");
            
            String query = "INSERT  INTO signup VALUES ( '" + formNo + "' , '"+ name+ "' , '"+ fname+ "' , '"+ date+ "' , '"+ gender+ "' , '"+ email+ "' , '"+ marital + "' , '"+ address + "' , '"+  city + "' , '"+  state + "' , '"+  pin+ "' ); ";
            c.s.executeUpdate(query);
            
            setVisible(false);
            new SignUpTwo(formNo).setVisible(true);
            
        }
        catch(Exception e){ 
            System.out.println(e);
        }
        
    }
    
    public static void main(String args[]){
        new SignUpOne();
    } 
    
}
