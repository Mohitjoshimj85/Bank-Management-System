package bank.managment.system;

import  javax.swing.*;
import java.awt.*;
import java.util.Date;
import java.awt.event.*;
import java.sql.*;

public class Withdrawl extends JFrame implements ActionListener {
    JTextField  amountField;
    JButton back , withdrawl;
    String pinNum;
    
    Withdrawl(String pin){
        setLayout(null);
        this.pinNum = pin;
        ImageIcon i1 =new ImageIcon(ClassLoader.getSystemResource("icons/atm.jpg"));
        ImageIcon i2= new ImageIcon(i1.getImage().getScaledInstance(900, 900, Image.SCALE_DEFAULT));
        JLabel image = new JLabel(i2);
        image.setBounds(0,0,900,900);
        add(image);
        
        JLabel instruct = new JLabel("Enter Amount, you want to Withdrawl");
        instruct.setForeground(Color.white);
        instruct.setFont(new Font("System" , Font.BOLD , 20));
        instruct.setBounds(180,200,350,35);
        image.add(instruct);
        
        amountField = new JTextField();
        amountField.setBounds(180, 260, 330, 30);
        amountField.setFont(new Font("System" , Font.BOLD , 25));
        image.add(amountField);
        
        back=  new JButton("Back");
        back.setBounds(170, 400, 150, 30);
        back.setForeground(Color.black);
        back.setBackground(Color.gray);
        back.addActionListener(this);
        image.add(back);
        
        withdrawl=  new JButton("withdrawl");
        withdrawl.setBounds(340, 400, 150, 30);
        withdrawl.setForeground(Color.black);
        withdrawl.setBackground(Color.green);
        withdrawl.addActionListener(this);
        image.add(withdrawl);
        
         getContentPane().setBackground(Color.white);
        setSize(900 , 900 );
        setLocation(300, 0);
        //setUndecorated(true);
        
        setVisible(true);
    }
    
    
    public void actionPerformed(ActionEvent ac) {
        if(ac.getSource()==withdrawl){
            
            String amount = amountField.getText();
            if(amount.equals("")){
                JOptionPane.showMessageDialog(null, "Please enter the amount you want to withdrawl");
            }
            else{
                Conn c = new Conn();
                try{
                    System.out.println("SELECT * FROM bank WHERE pinNum = '" + pinNum + "' ;");
                    ResultSet rs =c.s.executeQuery("SELECT * FROM bank WHERE pinNum = '" + pinNum + "' ;");
                    int balance =0;
                    while(rs.next()){
                        if( rs.getString("type"). equals("Deposit")){
                            balance += Integer.parseInt(rs.getString("amount"));
                        }
                        else{
                            balance -= Integer.parseInt(rs.getString("amount"));
                        }
                    }
                    if(balance < Integer.parseInt(amount)){
                        JOptionPane.showMessageDialog(null , "Insufficient Balance");
                         setVisible(false);
                        new Transaction(pinNum).setVisible(true);
                        return;
                    }
                    
                    Date date = new Date();
                    String query= "Insert INTO bank VALUES( '" + pinNum +"' , '" + date + "' , 'withdrawl' , '" + amount + "' );";
                    c.s.executeUpdate(query);
                    JOptionPane.showMessageDialog(null, "Rs-" + amount + " withdrawl sucessfully");
                     setVisible(false);
                    new Transaction(pinNum).setVisible(true);
                }
                catch(Exception e){
                    System.out.println(e);
                }
            }
            
        }
        else if(ac.getSource() == back){
            setVisible(false);
            new Transaction(pinNum).setVisible(true);
        }
            
    }
    
    public static void main(String args[]){
        new Withdrawl("");
    }

    
}
