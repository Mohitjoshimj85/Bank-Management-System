package bank.managment.system;

import java.sql.*;
public class Conn {
   Connection c;
   Statement s;
   public Conn(){
       
       try{
           c= DriverManager.getConnection("jdbc:mysql://localhost:3306/bankmanagementsystem", "root" , "mj@@11mj");
//JDBC:MYSQL://localhost:3306(defult for mysql so it is not necessary here)/name" , username,  passward;
            s =  c.createStatement();
       }
       catch(Exception e){
           System.out.println(e);
       }
       
   }
}
