package bank.managment.system;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;

public class SignUpThree extends JFrame implements ActionListener{
    String formNo;
    JRadioButton saving , fixed , current , recurring_deposit ;
    JCheckBox atm  , internetBanking , mobileBanking , emailSMSalert , chequeBook ,eStatement, checked;
    JButton submit , cancel;
    SignUpThree(String formNo){
        setLayout(null);
        
        this.formNo = formNo;
        
        JLabel page3= new JLabel("Page 3 : Additional Details ");
        page3.setFont(new Font("Ralewey" , Font.BOLD , 25));
        page3.setBounds(230, 60, 400, 30);
        add(page3);
        
        JLabel account= new JLabel("Account Type ");
        account.setFont(new Font("Ralewey" , Font.BOLD , 20));
        account.setBounds(100, 130, 300, 30);
        add(account);
        
        saving = new JRadioButton("Saving Account");
        saving.setBounds(100, 180, 200, 20);
        add(saving);
        
        fixed = new JRadioButton("Fixed Deposit Account");
        fixed.setBounds(400, 180, 200, 20);
        add(fixed);
        
        current = new JRadioButton("Current Account");
        current.setBounds(100, 220, 200, 20);
        add(current);
        
        recurring_deposit = new JRadioButton("Recurring Deposit Account");
        recurring_deposit.setBounds(400, 220, 200, 20);
        add(recurring_deposit);
        
        ButtonGroup accountGroup=  new ButtonGroup();
        accountGroup.add(saving);
        accountGroup.add(fixed);
        accountGroup.add(current);
        accountGroup.add(recurring_deposit);
        
        JLabel CardNum= new JLabel("Card Number :");
        CardNum.setFont(new Font("Ralewey" , Font.BOLD , 20));
        CardNum.setBounds(100, 290, 300, 30);
        add(CardNum);
        JLabel CardInstruct= new JLabel("Your 14 digit Card Number");
        CardInstruct.setFont(new Font("Ralewey" , Font.BOLD , 15));
        CardInstruct.setBounds(100, 320, 300, 25);
        add(CardInstruct);
        
        JLabel num1= new JLabel("XXXX-XXXX-XXXX-4321");
        num1.setFont(new Font("Ralewey" , Font.BOLD , 20));
        num1.setBounds(350, 300, 300, 25);
        add(num1);
        
        JLabel PinNum= new JLabel("Pin :");
        PinNum.setFont(new Font("Ralewey" , Font.BOLD , 20));
        PinNum.setBounds(100, 370, 300, 30);
        add(PinNum);
        JLabel pinInstruct= new JLabel("Your 4 digit Password");
        pinInstruct.setFont(new Font("Ralewey" , Font.BOLD , 15));
        pinInstruct.setBounds(100, 400, 300, 20);
        add(pinInstruct);
        
         JLabel num2= new JLabel("XXXX");
        num2.setFont(new Font("Ralewey" , Font.BOLD , 20));
        num2.setBounds(350, 380, 300, 25);
        add(num2);
        
        JLabel servicesRequired= new JLabel("Services Required :");
        servicesRequired.setFont(new Font("Ralewey" , Font.BOLD , 25));
        servicesRequired.setBounds(100, 450, 300, 30);
        add(servicesRequired);
        
        atm=  new JCheckBox("ATM CARD ");
        atm.setBounds(100, 500, 200, 20);
        add(atm);
        
        internetBanking=  new JCheckBox("Internet Banking");
        internetBanking.setBounds(400, 500, 200, 20);
        add(internetBanking);
        
        mobileBanking=  new JCheckBox("Mobile Banking");
        mobileBanking.setBounds(100, 550, 200, 20);
        add(mobileBanking);
        
        emailSMSalert=  new JCheckBox("EMAIL & SMS Alert");
        emailSMSalert.setBounds(400, 550, 200, 20);
        add(emailSMSalert);
        
        chequeBook=  new JCheckBox("Cheque Book");
        chequeBook.setBounds(100, 600, 200, 20);
        add(chequeBook);
        
        eStatement=  new JCheckBox("E-Statement");
        eStatement.setBounds(400, 600, 200, 20);
        add(eStatement);
        
        checked=  new JCheckBox("I heareby declares that the above entered details are connect to tha best of my knowledege ");
        checked.setBounds(100, 650, 500, 20);
        add(checked);
        
        submit = new JButton("Submit");
        submit.setBounds(550, 700, 80 , 25);
        submit.setBackground(Color.black);
        submit.setForeground(Color.white);
        submit.addActionListener(this);
        add(submit);
        
        cancel = new JButton("Submit");
        submit.setBounds(550, 700, 80 , 25);
        submit.setBackground(Color.black);
        submit.setForeground(Color.white);
        submit.addActionListener(this);
        add(submit);
        
//        ButtonGroup services= new ButtonGroup();
//        services.add(atm);
//        services.add(internetBanking);
//        services.add(mobileBanking);
//        services.add(emailSMSalert);
//        services.add(chequeBook);
//        services.add(eStatement);
        
        
        getContentPane().setBackground(Color.white);
        setSize(700 , 800 );
        setVisible(true);
        setLocation(420, 10);
        
          
    }
    
    public void actionPerformed(ActionEvent ac ){
        if(ac.getSource()== submit){
            String account = "" ;
            if(saving.isSelected()){
                account = "saving";
            }
            else if(fixed.isSelected()){
                account = "fixed";
            }
            else if(current.isSelected()){
                account = "current";
            }
            else if(recurring_deposit.isSelected()){
                account = "recurring";
            }
            
            String cardNum = "" +  Math.abs((new Random().nextLong() % 90000000l) + 12349870000000l);
            String pinNum =  "" +  Math.abs(new Random().nextLong()% 9000l + 1000l);
            
            String facility="";
            
            if(atm.isSelected()){
                facility += " Atm Card";
            }
            if(internetBanking.isSelected()){
                facility += " Internet Banking";
            }
            if(mobileBanking.isSelected()){
                facility += " Mobile Banking";
            }
            if(emailSMSalert.isSelected()){
                facility += " EMAIL & SMS Alert";
            }
            if(chequeBook.isSelected()){
                facility += " Cheque Book";
            }
            if(eStatement.isSelected()){
                facility += " E-Statement";
            }
            
            try{
                if(account==""){
                    JOptionPane.showMessageDialog(null, "Account Type is Required.");
                }
                else if(!checked.isSelected()){
                    JOptionPane.showMessageDialog(null, "Please Confirm it.");
                }
                else{
                        Conn c = new Conn();
                    System.out.println("INSERT  INTO signup3 VALUES ( '" + formNo + "' , '"+ account + "' , '"+ cardNum+ "' , '"+ pinNum + "' , '"+ facility +  "' ); ");
                        String query = "INSERT  INTO signup3 VALUES ( '" + formNo + "' , '"+ account + "' , '"+ cardNum+ "' , '"+ pinNum + "' , '"+ facility +  "' ); ";
                        c.s.executeUpdate(query);
                
                    System.out.println("INSERT  INTO login VALUES ( '" +  formNo + "' , '" + cardNum+ "' , '"+ pinNum + "' ); ");
                        String query2 = "INSERT  INTO login VALUES ( '" +  formNo + "' , '" + cardNum+ "' , '"+ pinNum + "' ); " ; 
                        c.s.executeUpdate(query2);
                
                        JOptionPane.showMessageDialog(null, "Card Number is : " + cardNum + "\n" + "pin is : " + pinNum);
                        setVisible(false);
                        new Deposit(pinNum).setVisible(true);
                }
                
                
            }
            catch(Exception e){
                System.out.println(e);
            }
            
        }
        else if( ac.getSource() == cancel){
            setVisible(true);
            new Login().setVisible(true);
        }
    }
    
    public static void main(String args[]){
        new SignUpThree("1626");
    }
}
