package bank.managment.system;
import  javax.swing.*;
import java.awt.*;
import java.util.Date;
import java.awt.event.*;
import java.sql.*;

public class Transaction extends JFrame implements ActionListener{
    
    JButton deposit, withdrawl, fastCash, statement , pinChange , balance , exit;
    String pinNum;
    Transaction(String pinNum){
        this.pinNum = pinNum;
        
        setLayout(null);
        
        ImageIcon i1 =new ImageIcon(ClassLoader.getSystemResource("icons/atm.jpg"));
        ImageIcon i2= new ImageIcon(i1.getImage().getScaledInstance(900, 900, Image.SCALE_DEFAULT));
        JLabel image = new JLabel(i2);
        image.setBounds(0,0,900,900);
        add(image);
        
        JLabel instruct1 = new JLabel("Please Select your Transaction");
        instruct1.setForeground(Color.white);
        instruct1.setFont(new Font("System" , Font.BOLD , 20));
        instruct1.setBounds(190,200,700,35);
        image.add(instruct1);
        
        deposit= new JButton("Deposit");
        deposit.setBounds(170, 300, 150, 30);
        deposit.setBackground(Color.white);
        deposit.setForeground(Color.black);
        deposit.addActionListener(this);
        image.add(deposit);
        
            withdrawl= new JButton("Cash Withdrawl");
        withdrawl.setBounds(340, 300, 150, 30);
         withdrawl.setBackground(Color.white);
        withdrawl.setForeground(Color.black);
        withdrawl.addActionListener(this);
        image.add(withdrawl);
        
        fastCash= new JButton("Fast Cash");
        fastCash.setBounds(170, 350, 150, 30);
        fastCash.setBackground(Color.white);
        fastCash.setForeground(Color.black);
        fastCash.addActionListener(this);
        image.add(fastCash);
        
            statement= new JButton("Mini Statement");
        statement.setBounds(340, 350, 150, 30);
        statement.setBackground(Color.white);
        statement.setForeground(Color.black);
        statement.addActionListener(this);
        image.add(statement);
        
        pinChange= new JButton("Pin Change");
        pinChange.setBounds(170, 400, 150, 30);
         pinChange.setBackground(Color.white);
        pinChange.setForeground(Color.black);
        pinChange.addActionListener(this);
        image.add(pinChange);
        
            balance= new JButton("Balance Enquiry");
        balance.setBounds(340, 400, 150, 30);
         balance.setBackground(Color.white);
        balance.setForeground(Color.black);
        balance.addActionListener(this);
        image.add(balance);
        
            exit= new JButton("Exit");
        exit.setBounds(340, 450, 150, 30);
        exit.setBackground(Color.white);
        exit.setForeground(Color.black);
        exit.addActionListener(this);
        image.add(exit);
        
        
        
        
        
        getContentPane().setBackground(Color.white);
        setSize(900 , 900 );
        setLocation(300, 0);
        setUndecorated(true);
        
        setVisible(true);
    }
    
    
    public void actionPerformed(ActionEvent ac ){
        if(ac.getSource() == exit){
            System.exit(0);
        }
        else if (ac.getSource() == deposit){
            setVisible(false);
            new Deposit(pinNum).setVisible(true);
        }
        else if (ac.getSource() == withdrawl){
            setVisible(false);
            new Withdrawl(pinNum).setVisible(true);
        }
        else if (ac.getSource() == fastCash){
            setVisible(false);
            new FastCash(pinNum).setVisible(true);
        }
        else if (ac.getSource() == statement){
            new MiniStatement(pinNum).setVisible(true);
           
        }
        else if (ac.getSource() == pinChange){
            setVisible(false);
            new PinChange(pinNum).setVisible(true);
        }
        else if (ac.getSource() == balance){
                new Balance(pinNum);
        }
        
        
    }
    
    public static void main(String args[]){
        new Transaction("");
    }
}
