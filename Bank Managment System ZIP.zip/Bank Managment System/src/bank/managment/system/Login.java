package bank.managment.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Login extends JFrame implements ActionListener {
    JButton login , signup , clear;
    JTextField  cardField;
    JPasswordField pinField;
    Login(){
        setTitle("ATM");
        setLayout(null);
        ImageIcon i1 =new ImageIcon(ClassLoader.getSystemResource("icons/bank.jpeg"));
        ImageIcon i2= new ImageIcon(i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT));
        JLabel label = new JLabel(i2);
        label.setBounds(100,10,100,100);
        add(label);
        
        JLabel text = new JLabel("Welcome to ATM");
        text.setFont(new Font("Osward" , Font.BOLD , 38));
        text.setBounds(300, 40, 400, 40);
        add(text);
       
        JLabel cardno = new JLabel("Card No. :");
        cardno.setFont(new Font("Raleway" , Font.BOLD , 38));
        cardno.setBounds(120, 150, 200, 30);
        add(cardno);
        
        cardField= new JTextField();
        cardField.setBounds(330 , 150, 220, 30); 
        cardField.setFont(new Font("Rateway" , Font.BOLD , 14));
        add(cardField);
        
        JLabel pin = new JLabel("Pin :");
        pin.setFont(new Font("Raleway" , Font.BOLD , 38));
        pin.setBounds(120, 220, 200, 30);
        add(pin);
        
        pinField= new JPasswordField();
        pinField.setFont(new Font("Rateway" , Font.BOLD , 14));
        pinField.setBounds(330 , 220, 220, 30);
        add(pinField);
        
        login = new JButton("Log In");
        login.setBounds(330, 300, 100, 30);
        login.setBackground(Color.black);
        login.setForeground(Color.white);
        login.addActionListener(this);
        add(login);
        
        clear = new JButton("Clear");
        clear.setBackground(Color.black);
        clear.setBounds(450, 300, 100, 30);
        clear.setForeground(Color.white);
        clear.addActionListener(this);
        add(clear);
        
        signup = new JButton("Sign up");
        signup.setBounds(330, 350, 220, 30);
        signup.setBackground(Color.black);
        signup.setForeground(Color.white);
        signup.addActionListener(this);
        add(signup);
        
        getContentPane().setBackground(Color.white);
        setSize(800 , 480 );
        setVisible(true);
        setLocation(350, 200);
    }
    public void actionPerformed(ActionEvent ac){
        if(ac.getSource() == clear){
            cardField.setText("");
            pinField.setText("");
        }
        else if( ac.getSource() == login){
            Conn c= new Conn();
            String cardNum = cardField.getText();
            char[] pinChars = pinField.getPassword();
            String pinNum = new String(pinChars);
            System.out.println("Select * from login where cardNum = '" + cardNum + "' and  pinNum = '" + pinNum + "';");
            String query = "Select * from login where cardNum = '" + cardNum + "' and  pinNum = '" + pinNum + "' ;";
            
            try{
               ResultSet rs = c.s.executeQuery(query);
               if(rs.next()){
                   setVisible(false);
                   new Transaction(pinNum).setVisible(true);
               }
               else {
                   JOptionPane.showMessageDialog(null, "Incorrect card number or pin");
               }
            }
            catch(Exception e){
                System.out.println(e);
            }
        } 
        else if(ac.getSource() == signup){
            setVisible(false);
            new SignUpOne().setVisible(true);
        }
    }
    
    public static void main(String args[]){
        new Login();
    }
}