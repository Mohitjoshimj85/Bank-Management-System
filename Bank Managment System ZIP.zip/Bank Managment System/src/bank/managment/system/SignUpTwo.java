package bank.managment.system;

import  javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;

public class SignUpTwo extends JFrame implements ActionListener{
    JTextField religionField, educationField, occupationField, panField ,stateField, aadharField;
    JComboBox religionbox , categorybox , incomebox , educationbox , occupationbox ;
    JRadioButton EYes , ENo , SYes , SNo;
    String formNo ;
    SignUpTwo(String formNo){
        setLayout(null);
        
        this.formNo = formNo;
        
        JLabel page2= new JLabel("Page 2 : Additional Details ");
        page2.setFont(new Font("Ralewey" , Font.BOLD , 25));
        page2.setBounds(280, 80, 400, 30);
        add(page2);
        
        JLabel religion= new JLabel("Religion : ");
        religion.setFont(new Font("Raleway" , Font.BOLD , 25));
        religion.setBounds(150, 140, 200, 30);
        add(religion);
        
        String rel[] = {"Select" , "Hindu" , "Muslim" , "Sikh" };
        religionbox = new JComboBox(rel);
        religionbox.setBackground(Color.white);
        religionbox.setBounds(400, 140, 300, 30);
        add(religionbox);
        
        
        JLabel category= new JLabel("Category: ");
        category.setFont(new Font("Raleway" , Font.BOLD , 25));
        category.setBounds(150, 190, 200, 30);
        add(category);
        
         String cat[] = {"Select" ,"General", "Sc" , "St" , "Obc" };
        categorybox = new JComboBox(cat);
        categorybox.setBackground(Color.white);
        categorybox.setBounds(400, 190, 300, 30);
        add(categorybox);
       
        
        JLabel income = new JLabel("Income : ");
        income.setFont(new Font("Raleway" , Font.BOLD , 25));
        income.setBounds(150, 230, 200, 30);
        add(income);
        
        String inco[] = {"Select" , " < 1,00,000" , " < 3,00,000" , " < 5,00,000" , " > 5,00,000" };
        incomebox = new JComboBox(inco);
        incomebox.setBackground(Color.white);
        incomebox.setBounds(400,230, 300, 30);
        add(incomebox);
        
        JLabel education= new JLabel("Educational: ");
        education.setFont(new Font("Raleway" , Font.BOLD , 25));
        education.setBounds(150, 290, 200, 30);
        add(education);
        JLabel education1= new JLabel("Qualification: ");
        education1.setFont(new Font("Raleway" , Font.BOLD , 25));
        education1.setBounds(150, 315, 200, 30);
        add(education1);
        
        String edcu[] = {"Select", "High-School" , "Inter-Mediate"  , "Graduate" , "Post-Graduate" };
        educationbox = new JComboBox(edcu);
        educationbox.setBackground(Color.white);
        educationbox.setBounds(400, 305, 300, 30);
        add(educationbox);
        
        
        JLabel occupation= new JLabel("Occupation : ");
        occupation.setFont(new Font("Raleway" , Font.BOLD , 25));
        occupation.setBounds(150, 380, 200, 30);
        add(occupation);
        
        String occu[] = {"Select", "Teacher" , "Engineer"  , "police" , "other" };
        occupationbox = new JComboBox(occu);
        occupationbox.setBackground(Color.white);
        occupationbox.setBounds(400, 380, 300, 30);
        add(occupationbox); 
        
        JLabel pan= new JLabel("Pan Number : ");
        pan.setFont(new Font("Raleway" , Font.BOLD , 25));
        pan.setBounds(150, 430, 200, 30);
        add(pan);
        
        panField = new JTextField();
        panField.setFont(new Font("Raleway" ,Font.BOLD , 20));
        panField.setBounds(400, 430, 300, 30);
        add(panField);
       
        JLabel aadhar= new JLabel("Aadhar : ");
        aadhar.setFont(new Font("Raleway" , Font.BOLD , 25));
        aadhar.setBounds(150, 480, 200, 30);
        add(aadhar);
        
        aadharField = new JTextField();
        aadharField.setFont(new Font("Raleway" ,Font.BOLD , 20));
        aadharField.setBounds(400, 480, 300, 30);
        add(aadharField);
        
        JLabel senior= new JLabel("Senior citizen : ");
        senior.setFont(new Font("Raleway" , Font.BOLD , 25));
        senior.setBounds(150, 530, 200, 30);
        add(senior);
        
        SYes= new JRadioButton("Yes");
        SYes.setBounds(400, 530, 100, 30);
        add(SYes);
        
        SNo = new JRadioButton("No");
        SNo.setBounds(600, 530, 100, 30);
        add(SNo);       
        
        ButtonGroup seniorGroup= new ButtonGroup();
        seniorGroup.add(SYes);
        seniorGroup.add(SNo);
        
        JLabel account= new JLabel("Existing Account : ");
        account.setFont(new Font("Raleway" , Font.BOLD , 25));
        account.setBounds(150, 580, 250, 30);
        add(account);
        
        EYes= new JRadioButton("Yes");
        EYes.setBounds(400, 580, 100, 30);
        add(EYes);
        
        ENo = new JRadioButton("No");
        ENo.setBounds(600, 580, 100, 30);
        add(ENo);
        
        ButtonGroup accountGroup= new ButtonGroup();
        accountGroup.add(EYes);
        accountGroup.add(ENo);
        
        JButton nextButton= new JButton();
        nextButton.setText("NEXT");
        nextButton.setFont(new Font("RaleWay", Font.BOLD ,25));
        nextButton.setBounds(600, 650, 110, 40);
        nextButton.addActionListener(this);
        add(nextButton);
        
        getContentPane().setBackground(Color.white);
        setSize(850 , 800 );
        setVisible(true);
        setLocation(350, 10);
        
    }
    
    public void actionPerformed(ActionEvent ac ){
        String religion = (String)religionbox.getSelectedItem();
        String category = (String)categorybox.getSelectedItem();
        String income = (String)incomebox.getSelectedItem();
        String education = (String)educationbox.getSelectedItem(); 
        String occupation = (String)occupationbox.getSelectedItem();
        String pan =  panField.getText();
        String aadhar = aadharField.getText() ; 
         
        String senior =  null;
        if(SYes.isSelected()){
            senior = "Yes";
        }else if( SNo.isSelected()){
            senior = "No";
        }
        
        String account = null;
        if(EYes.isSelected()){
            account = "Yes";
        }else if( ENo.isSelected()){
            account = "No";
        }
        
        try {
            Conn c =  new Conn();
            System.out.println("INSERT  INTO signup2 VALUES ( '" + formNo + "' , '"+ religion+ "' , '"+ category+ "' , '"+ income + "' , '"+ education+ "' , '"+ occupation + "' , '"+  pan + "' , '"+  aadhar +"' , '"+ senior+ "' , '" + account +  "' ); ");
            
            String query = "INSERT  INTO signup2 VALUES ( '" + formNo + "' , '"+ religion+ "' , '"+ category+ "' , '"+ income + "' , '"+ education+ "' , '"+ occupation + "' , '"+  pan + "' , '"+  aadhar +"' , '"+ senior+ "' , '" + account +  "' ); ";
            c.s.executeUpdate(query);
             setVisible(false);
            new SignUpThree(formNo).setVisible(true);
        }
        catch(Exception e){ 
            System.out.println(e);
        }
        
        
        
    }
    
    public static void main(String args[]){
        new SignUpTwo("");
    } 
    
}
