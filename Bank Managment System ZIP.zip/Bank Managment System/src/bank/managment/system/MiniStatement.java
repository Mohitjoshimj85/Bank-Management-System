package bank.managment.system;

import java.awt.*;
import java.sql.ResultSet;
import javax.swing.*;

public class MiniStatement extends JFrame {

    MiniStatement(String pinNum) {
        setLayout(null);
        JLabel label = new JLabel("Bank Statement");
        label.setFont(new Font("System", Font.BOLD, 25));
        label.setBounds(100, 10, 200, 30);
        add(label);

        JLabel card = new JLabel();
        card.setBounds(10, 50, 200, 30);
        add(card);

        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT * FROM login WHERE pinNum = '" + pinNum + "' ;");

            while (rs.next()) {
                card.setText("Card Number : " + rs.getString("cardNum").substring(0, 4) + "XXXXXX" + rs.getString("cardNum").substring(10));
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        JLabel statement = new JLabel();
        statement.setBounds(10, 100, 300, 300); // Adjusted height for more space
        add(statement);

        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT * FROM bank WHERE pinNum = '" + pinNum + "' ;");

            StringBuilder sb = new StringBuilder("<html>");
            while (rs.next()) {
                sb.append(rs.getString("date"))
                  .append("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;")
                  .append(rs.getString("type"))
                  .append("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;")
                  .append(rs.getString("amount"))
                  .append("<br><br>");
            }
            sb.append("</html>");
            statement.setText(sb.toString());

        } catch (Exception e) {
            System.out.println(e);
        }

        getContentPane().setBackground(Color.white);
        setSize(400, 480);
        setVisible(true);
        setLocation(20, 20);
    }

    public static void main(String args[]) {
        new MiniStatement("5680");
    }
}
