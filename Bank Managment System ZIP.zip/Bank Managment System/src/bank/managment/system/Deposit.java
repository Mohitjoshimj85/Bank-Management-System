package bank.managment.system;
import  javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;

public class Deposit extends JFrame implements ActionListener {
    
    JTextField  amountField;
    JButton back , deposit;
    String pinNum;
    
    Deposit(String pin){
        setLayout(null);
        this.pinNum = pin;
        ImageIcon i1 =new ImageIcon(ClassLoader.getSystemResource("icons/atm.jpg"));
        ImageIcon i2= new ImageIcon(i1.getImage().getScaledInstance(900, 900, Image.SCALE_DEFAULT));
        JLabel image = new JLabel(i2);
        image.setBounds(0,0,900,900);
        add(image);
        
        JLabel instruct = new JLabel("Enter Amount, you want to Deposit");
        instruct.setForeground(Color.white);
        instruct.setFont(new Font("System" , Font.BOLD , 20));
        instruct.setBounds(180,200,350,35);
        image.add(instruct);
        
        amountField = new JTextField();
        amountField.setBounds(180, 260, 330, 30);
        amountField.setFont(new Font("System" , Font.BOLD , 25));
        image.add(amountField);
        
        back=  new JButton("Back");
        back.setBounds(170, 400, 150, 30);
        back.setForeground(Color.black);
        back.setBackground(Color.gray);
        back.addActionListener(this);
        image.add(back);
        
        deposit=  new JButton("Deposit");
        deposit.setBounds(340, 400, 150, 30);
        deposit.setForeground(Color.black);
        deposit.setBackground(Color.green);
        deposit.addActionListener(this);
        image.add(deposit);
        
         getContentPane().setBackground(Color.white);
        setSize(900 , 900 );
        setLocation(300, 0);
        //setUndecorated(true);
        
        setVisible(true);
    }
    
    
    public void actionPerformed(ActionEvent ac) {
        if(ac.getSource()==deposit){
            
            String amount = amountField.getText();
            Date date = new Date();
            
            if(amount.equals("")){
                JOptionPane.showMessageDialog(null, "Please enter the amount you want to deposit");
            }
            else{
                try{
                    Conn c = new Conn();
                    String query= "Insert INTO bank VALUES( '" + pinNum +"' , '" + date + "' , 'Deposit' , '" + amount + "' );";
                    c.s.executeUpdate(query);
                    JOptionPane.showMessageDialog(null, "Rs-" + amount + " Deposited sucessfully");
                    setVisible(false);
                    new Transaction(pinNum).setVisible(true);
                
                }
                catch(Exception e){
                    System.out.println(e);
                }
            }
            
        }
        else if(ac.getSource() == back){
            setVisible(false);
            new Transaction(pinNum).setVisible(true);
        }
            
    }
    
    public static void main(String args[]){
        new Deposit("1234");
    }

    
}
