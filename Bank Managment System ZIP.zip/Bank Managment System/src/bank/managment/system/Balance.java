package bank.managment.system;

import  javax.swing.*;
import java.awt.*;
import java.util.Date;
import java.awt.event.*;
import java.sql.*;

public class Balance extends JFrame  {
    Balance(String pinNum){
        
        Conn c = new Conn();
                try{
                    System.out.println("SELECT * FROM bank WHERE pinNum = '" + pinNum + "' ;");
                    ResultSet rs =c.s.executeQuery("SELECT * FROM bank WHERE pinNum = '" + pinNum + "' ;");
                    int balance =0;
                    while(rs.next()){
                        if( rs.getString("type"). equals("Deposit")){
                            balance += Integer.parseInt(rs.getString("amount"));
                        }
                        else{
                            balance -= Integer.parseInt(rs.getString("amount"));
                        }
                    }
                    JOptionPane.showMessageDialog(null, "Balance : Rs-" + balance );
                    
                }
                catch(Exception e){
                    System.out.println(e);
                }
    }
    
    public static void main(String args[]){
        new Balance("");
    }

    
}
 