package bank.managment.system;


import  javax.swing.*;
import java.awt.*;
import java.util.Date;
import java.awt.event.*;
import java.sql.*;

public class PinChange extends JFrame implements ActionListener {
    JPasswordField  pin1Field , pin2Field;
    JButton back , change;
    String pinNum;
    
    PinChange(String pin){
        setLayout(null);
        this.pinNum = pin;
        ImageIcon i1 =new ImageIcon(ClassLoader.getSystemResource("icons/atm.jpg"));
        ImageIcon i2= new ImageIcon(i1.getImage().getScaledInstance(900, 900, Image.SCALE_DEFAULT));
        JLabel image = new JLabel(i2);
        image.setBounds(0,0,900,900);
        add(image);
        
        JLabel instruct = new JLabel("Enter New Pin");
        instruct.setForeground(Color.white);
        instruct.setFont(new Font("System" , Font.BOLD , 20));
        instruct.setBounds(260,200,350,35);
        image.add(instruct);
        
   
        JLabel pin1 = new JLabel("New-Pin");
        pin1.setForeground(Color.white);
        pin1.setFont(new Font("System" , Font.BOLD , 20));
        pin1.setBounds(180,250,100,35);
        image.add(pin1);
        
        pin1Field = new JPasswordField();
        pin1Field.setBounds(300, 250, 200, 30);
        pin1Field.setFont(new Font("System" , Font.BOLD , 25));
        image.add(pin1Field);
        
        JLabel pin2 = new JLabel("ReEnter-Pin");
        pin2.setForeground(Color.white);
        pin2.setFont(new Font("System" , Font.BOLD , 20));
        pin2.setBounds(180,300,100,35);
        image.add(pin2);
        
        pin2Field = new JPasswordField();
        pin2Field.setBounds(300, 300, 200, 30);
        pin2Field.setFont(new Font("System" , Font.BOLD , 25));
        image.add(pin2Field);
        
        back=  new JButton("Back");
        back.setBounds(170, 450, 150, 30);
        back.setForeground(Color.black);
        back.setBackground(Color.gray);
        back.addActionListener(this);
        image.add(back);
        
        change=  new JButton("Change");
        change.setBounds(340, 450, 150, 30);
        change.setForeground(Color.black);
        change.setBackground(Color.green);
        change.addActionListener(this);
        image.add(change);
        
         getContentPane().setBackground(Color.white);
        setSize(900 , 900 );
        setLocation(300, 0);
        //setUndecorated(true);
        
        setVisible(true);
    }
    
    
    public void actionPerformed(ActionEvent ac) {
        if(ac.getSource()==change){
            
            String pin1 = pin1Field.getText();
            String pin2 = pin2Field.getText();
            if(pin1.equals(pin2)){
                Conn c = new Conn();
                try{
                    String query1 = "UPDATE login SET pinNum = '" + pin1 + "' WHERE pinNum = '" + pinNum + "';";
                    String query2 = "UPDATE signup3 SET pinNum = '" + pin1 + "' WHERE pinNum = '" + pinNum + "';";
                    String query3 = "UPDATE bank SET pinNum = '" + pin1 + "' WHERE pinNum = '" + pinNum + "';";
                    c.s.executeUpdate(query1);
                    c.s.executeUpdate(query2);
                    c.s.executeUpdate(query3);
                    JOptionPane.showMessageDialog(null, "Pin Updated sucessfully");
                     
                    
                    setVisible(false);
                    new Transaction(pinNum).setVisible(true);
                }
                catch(Exception e){
                    System.out.println(e);
                }
            }
            else {
                JOptionPane.showMessageDialog(null, "Pin are not matching");
            }
            
        }
        else if(ac.getSource() == back){
            setVisible(false);
            new Transaction(pinNum).setVisible(true);
        }
            
    }
    
    public static void main(String args[]){
        new PinChange("");
    }

    
}
