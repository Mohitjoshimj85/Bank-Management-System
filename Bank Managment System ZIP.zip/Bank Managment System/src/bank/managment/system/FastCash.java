
package bank.managment.system;
import  javax.swing.*;
import java.awt.*;
import java.util.Date;
import java.awt.event.*;
import java.sql.*;

public class FastCash extends JFrame implements ActionListener{
    JButton m1, m2, m3, m4 , m5 , m6 , back;
    String pinNum;
    FastCash(String pinNum){
        this.pinNum = pinNum;
        
        setLayout(null);
        
        ImageIcon i1 =new ImageIcon(ClassLoader.getSystemResource("icons/atm.jpg"));
        ImageIcon i2= new ImageIcon(i1.getImage().getScaledInstance(900, 900, Image.SCALE_DEFAULT));
        JLabel image = new JLabel(i2);
        image.setBounds(0,0,900,900);
        add(image);
        
        JLabel instruct1 = new JLabel("Please Select your Transaction");
        instruct1.setForeground(Color.white);
        instruct1.setFont(new Font("System" , Font.BOLD , 20));
        instruct1.setBounds(190,200,700,35);
        image.add(instruct1);
        
        
        m1= new JButton("Rs 100");
        m1.setBounds(170, 300, 150, 30);
        m1.setBackground(Color.white);
        m1.setForeground(Color.black);
        m1.addActionListener(this);
        image.add(m1);
        
            m2= new JButton("Rs 500");
        m2.setBounds(340, 300, 150, 30);
         m2.setBackground(Color.white);
        m2.setForeground(Color.black);
        m2.addActionListener(this);
        image.add(m2);
        
        m3= new JButton("Rs 1000");
        m3.setBounds(170, 350, 150, 30);
        m3.setBackground(Color.white);
        m3.setForeground(Color.black);
        m3.addActionListener(this);
        image.add(m3);
        
            m4= new JButton("Rs 2000");
        m4.setBounds(340, 350, 150, 30);
        m4.setBackground(Color.white);
        m4.setForeground(Color.black);
        m4.addActionListener(this);
        image.add(m4);
        
        m5= new JButton("Rs 5000");
        m5.setBounds(170, 400, 150, 30);
         m5.setBackground(Color.white);
        m5.setForeground(Color.black);
        m5.addActionListener(this);
        image.add(m5);
        
            m6= new JButton("Rs 10000");
        m6.setBounds(340, 400, 150, 30);
         m6.setBackground(Color.white);
        m6.setForeground(Color.black);
        m6.addActionListener(this);
        image.add(m6);
        
            back= new JButton("BACK");
        back.setBounds(340, 450, 150, 30);
        back.setBackground(Color.white);
        back.setForeground(Color.black);
        back.addActionListener(this);
        image.add(back);
        
        
        
        
        
        getContentPane().setBackground(Color.white);
        setSize(900 , 900 );
        setLocation(300, 0);
        setUndecorated(true);
        
        setVisible(true);
    }
    
    
    public void actionPerformed(ActionEvent ac ){
        if(ac.getSource() == back){
             setVisible(false);
            new Transaction(pinNum).setVisible(true);
        }
        else {
            String amount ="";
            if (ac.getSource() == m1){
                amount = "100";
            }
            else if (ac.getSource() == m2){
                amount = "500";
            }
            else if (ac.getSource() == m3){
                amount = "1000";
             }
            else if (ac.getSource() == m4){
                amount = "2000";
            }
            else if (ac.getSource() == m5){
                amount = "5000";
            }
            else if (ac.getSource() == m6){
                amount = "10000";
            }
            
            Conn c = new Conn();
                try{
                    ResultSet rs =c.s.executeQuery("SELECT * FROM bank WHERE pinNum = '" + pinNum + "' ;");
                    int balance =0;
                    while(rs.next()){
                        if( rs.getString("type"). equals("Deposit")){
                            balance += Integer.parseInt(rs.getString("amount"));
                        }
                        else{
                            balance -= Integer.parseInt(rs.getString("amount"));
                        }
                    }
                    if(balance < Integer.parseInt(amount)){
                        JOptionPane.showMessageDialog(null , "Insufficient Balance");
                        setVisible(false);
                        new Transaction(pinNum).setVisible(true);
                        return;
                    }
                    
                     Date date = new Date();
                    String query= "Insert INTO bank VALUES( '" + pinNum +"' , '" + date + "' , 'withdrawl' , '" + amount + "' );";
                    c.s.executeUpdate(query);
                    JOptionPane.showMessageDialog(null, "Rs-" + amount + " withdrawl sucessfully");
                     setVisible(false);
                    new Transaction(pinNum).setVisible(true);
                
            
                }
                catch(Exception e){
                    System.out.println(e);
                }
            
        
        }
    }
    
    public static void main(String args[]){
        new FastCash("");
    }
}